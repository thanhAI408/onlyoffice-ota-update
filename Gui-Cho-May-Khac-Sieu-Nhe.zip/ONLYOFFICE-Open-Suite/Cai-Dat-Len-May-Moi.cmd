@echo off
chcp 65001 >nul
set "SUITE_DIR=%~dp0"
set "PORTABLE_DIR=%SUITE_DIR%portable"
set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"

echo ======================================================================
echo   CAI DAT BO UNG DUNG VAN PHONG (WORD, EXCEL, POWERPOINT, PDF)
echo ======================================================================
echo.

if not exist "%PORTABLE_DIR%" mkdir "%PORTABLE_DIR%"
taskkill /f /im OnlyOfficeLauncher.exe >nul 2>&1

echo [1/2] Dang khoi tao trinh khoi dong va cau nối ChemDraw -> Word...
if exist "%SUITE_DIR%icons\OfficeSuite.ico" (
    "%CSC%" /nologo /target:winexe /optimize+ /out:"%PORTABLE_DIR%\OnlyOfficeLauncher.exe" /win32icon:"%SUITE_DIR%icons\OfficeSuite.ico" /r:System.dll,System.Drawing.dll,System.Windows.Forms.dll,System.IO.Compression.FileSystem.dll "%PORTABLE_DIR%\OnlyOfficeLauncher.cs" >nul
) else (
    "%CSC%" /nologo /target:winexe /optimize+ /out:"%PORTABLE_DIR%\OnlyOfficeLauncher.exe" /r:System.dll,System.Drawing.dll,System.Windows.Forms.dll,System.IO.Compression.FileSystem.dll "%PORTABLE_DIR%\OnlyOfficeLauncher.cs" >nul
)

echo [2/2] Dang cai dat bieu tuong ngoai man hinh Desktop va kich hoat chay ngam...
"%PORTABLE_DIR%\OnlyOfficeLauncher.exe" --install

echo.
echo ======================================================================
echo   HOAN TAT 100%!
echo   - Da tao Word, Excel, PowerPoint, PDF ngoai man hinh Desktop!
echo   - Da kich hoat Copy hinh tu ChemDraw dan thang vao Word (Ctrl+V)!
echo ======================================================================
timeout /t 3
