# HƯỚNG DẪN SỬ DỤNG NHANH

### 1. Dùng hàng ngày
Mở thư mục ra, cần dùng phần nào thì **bấm đúp trực tiếp vào biểu tượng đó**:
- 🟦 **`ONLYOFFICE Word (Document)`**: Soạn thảo văn bản **Word** (`.docx`).
- 🟩 **`ONLYOFFICE Excel (Spreadsheet)`**: Làm bảng tính **Excel** (`.xlsx`).
- 🟧 **`ONLYOFFICE PowerPoint (Slide)`**: Làm trình chiếu **PowerPoint** (`.pptx`).
- 🟥 **`ONLYOFFICE PDF & Form Editor`**: Đọc, chỉnh sửa **PDF** & tạo biểu mẫu (`.pdf`).
- 🌈 **`ONLYOFFICE Suite (Open Source)`**: Mở trang chủ quản lý chung tất cả.

---

### 2. Khi chia sẻ cho người khác (Google Drive / USB)
1. Nén thư mục **`ONLYOFFICE-Open-Suite`** thành file **`.zip`** rồi tải lên Google Drive (hoặc chép vào USB).
2. Người nhận tải về máy, **Giải nén (Extract All)** ra.
3. Bấm đúp vào file **`Cai-Dat-Len-May-Moi.cmd`** **đúng 1 lần duy nhất** (mất 2 giây) $\rightarrow$ Xong! Từ lần sau bấm thẳng vào 5 biểu tượng ở trên để dùng.
